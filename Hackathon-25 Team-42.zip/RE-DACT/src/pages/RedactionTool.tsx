import React, { useState, ChangeEvent } from 'react';
import { FileUp, Copy, Download, Shield, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

interface RedactionLevel {
  id: string;
  label: string;
  description: string;
}

const REDACTION_LEVELS: RedactionLevel[] = [
  {
    id: '1',
    label: 'Entity Labels',
    description: 'Replace with descriptive labels (e.g., [NAME], [EMAIL])',
  },
  {
    id: '2',
    label: 'Mask with Asterisks',
    description: 'Replace sensitive data with asterisks (*****)',
  },
  {
    id: '3',
    label: 'Full Redaction',
    description: 'Replace with [REDACTED]',
  },
];

function RedactionTool() {
  const [text, setText] = useState('');
  const [level, setLevel] = useState('1');
  const [redactedText, setRedactedText] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const { signOut, user } = useAuth();
  const navigate = useNavigate();

  const handleTextChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleLevelChange = (e: ChangeEvent<HTMLSelectElement>) => {
    setLevel(e.target.value);
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const handleRedact = () => {
    let result = text;
    
    switch (level) {
      case '1':
        // Replace common patterns with entity labels
        result = result
          .replace(/[A-Z][a-z]+ [A-Z][a-z]+/g, '[NAME]')
          .replace(/\b[\w\.-]+@[\w\.-]+\.\w+\b/g, '[EMAIL]')
          .replace(/\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g, '[PHONE]')
          .replace(/\b\d{16}\b|\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/g, '[CREDIT_CARD]');
        break;
      case '2':
        // Replace with asterisks while preserving word length
        result = result.replace(/\S+/g, match => '*'.repeat(match.length));
        break;
      case '3':
        // Full redaction
        result = result.replace(/\S+/g, '[REDACTED]');
        break;
    }
    
    setRedactedText(result);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-gray-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-emerald-400" />
            <h1 className="text-3xl font-bold text-emerald-400">RE-DACT</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-gray-400">{user?.email}</span>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-xl p-6 shadow-xl mb-8">
          <div className="space-y-6">
            <div>
              <label htmlFor="text" className="block text-sm font-medium mb-2">
                Text Input
              </label>
              <textarea
                id="text"
                value={text}
                onChange={handleTextChange}
                className="w-full h-32 px-4 py-2 bg-gray-700 rounded-lg focus:ring-2 focus:ring-emerald-400 focus:outline-none"
                placeholder="Paste or type your sensitive content..."
              />
            </div>

            <div>
              <label htmlFor="level" className="block text-sm font-medium mb-2">
                Redaction Level
              </label>
              <select
                id="level"
                value={level}
                onChange={handleLevelChange}
                className="w-full px-4 py-2 bg-gray-700 rounded-lg focus:ring-2 focus:ring-emerald-400 focus:outline-none"
              >
                {REDACTION_LEVELS.map((level) => (
                  <option key={level.id} value={level.id}>
                    Level {level.id} - {level.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Upload Image (Optional)
              </label>
              <div className="flex items-center justify-center w-full">
                <label className="w-full flex flex-col items-center px-4 py-6 bg-gray-700 rounded-lg cursor-pointer hover:bg-gray-600 transition-colors">
                  <FileUp className="w-8 h-8 text-emerald-400 mb-2" />
                  <span className="text-sm text-gray-400">PNG, JPG up to 10MB</span>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/png,image/jpeg"
                    onChange={handleFileChange}
                  />
                </label>
              </div>
              {previewUrl && (
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="mt-4 rounded-lg max-h-48 mx-auto"
                />
              )}
            </div>

            <button
              onClick={handleRedact}
              className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-600 rounded-lg font-medium transition-colors"
            >
              Redact Content
            </button>
          </div>
        </div>

        {redactedText && (
          <div className="bg-gray-800 rounded-xl p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium">Redacted Output</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => copyToClipboard(redactedText)}
                  className="p-2 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <Copy className="w-5 h-5" />
                </button>
                <button
                  onClick={() => {
                    const blob = new Blob([redactedText], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'redacted-text.txt';
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="p-2 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <Download className="w-5 h-5" />
                </button>
              </div>
            </div>
            <pre className="w-full p-4 bg-gray-700 rounded-lg whitespace-pre-wrap font-mono text-sm">
              {redactedText}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

export default RedactionTool;